using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour
{
    // Variables for timer method and UI.
    private int timeText = 0;

    private float decimalTimeText;

    public int finalTime;

    //UI components
    Text TimeUI;
    
    Text survivalTimeText;

    // Healthbar script
    HealthBar healthBar;

    // Start is called before the first frame update
    void Start()
    {
        // Find timer GameObject component
        TimeUI = GameObject.Find("TimerText").GetComponent<Text>();

        // Find healthBar script
        healthBar = GameObject.Find("HealthBar").GetComponent<HealthBar>();
    }

    // Update is called once per frame
    void Update()
    {
        // Find survivalTimeText GameObject component. 
        survivalTimeText = GameObject.Find("SurvivalTimeNumber").GetComponent<Text>();

        // Set survival Time Text in UI.
        survivalTimeText.text = $"{finalTime}s";

        // Timer goes up when alive.
        if (healthBar.TotalHealth > 0)
            {
                AddToTimer();
            }

        // Final time is set when dead.
        else
            {
                finalTime = timeText;
            }    
    }

    // Method to make a timer that shows in UI.
    public void AddToTimer()
    {
        decimalTimeText += 1 * Time.deltaTime;

        timeText = Mathf.RoundToInt(decimalTimeText);

        TimeUI.text = $"{timeText}s";
    }


}
