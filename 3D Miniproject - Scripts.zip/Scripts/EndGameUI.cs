using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class EndGameUI : MonoBehaviour
{
    //Endgame Objects defined in inspector.
    [SerializeField] public GameObject endGame;
    [SerializeField] public Canvas endGameUI;

    //Script Access.
    HealthBar healthBar;

    //Game Over Bool.
    [Header("Determine Game Over")]
    [SerializeField] bool GameOver = false;


    // Start is called before the first frame update
    void Start()
    {
        // Make game run at normal speed.
        Time.timeScale = 1;

        // Set game to not be over.
        GameOver = false;

        // Find UI Game Objects
        healthBar = GameObject.Find("HealthBar").GetComponent<HealthBar>();
    }

    // Update is called once per frame
    void Update()
    {
        //When game is over run the dead method.
        if (GameOver == true)
        {
            Dead();
        }

        //Hide endgame UI.
        else if (GameOver == false)
        {
            endGameUI.enabled = false;
        }
        
        //Requirements for game to end
        if (healthBar.TotalHealth <= 0 || Input.GetKeyDown(KeyCode.Escape))
            {
                healthBar.TotalHealth = 0;
                GameOver = true;
            }

    }

    // Method to run when dead
    public void Dead()
    {
        GameOver = true;

    // Pause game in background.
        Time.timeScale = 0;

    // Show the endgame UI.
        endGameUI.enabled = true;

    // Play again.
        if (Input.GetKeyDown(KeyCode.Alpha1))
            {
                Debug.Log("Game Restarted");
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
            }

    // Quit game.
        if (Input.GetKeyDown(KeyCode.Alpha2))
            {
                Debug.Log("Game Quit");
                Application.Quit();
            }
    }
}
