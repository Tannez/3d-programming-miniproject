using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MagazinePickUp : MonoBehaviour
{

    // Magazine Object.
    [Header ("Magazine Object")]
    [SerializeField] GameObject Mag;

    // Access gun script.
    Gun gun;

    // Start is called before the first frame update
    void Start()
    {
        // Find gun script.
        gun = GameObject.Find("PlayerCameraRoot").GetComponentInChildren<Gun>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    // Trigger to let player pickup mag and add to their bullets meter.
    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            gun.bulletsLeft += 20;
            Debug.Log("Bullets Added");

            Destroy(this.Mag);
        }
    }
}
