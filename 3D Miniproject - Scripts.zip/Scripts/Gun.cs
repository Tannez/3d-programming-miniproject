using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Gun : MonoBehaviour
{
    //Inspiration for script
    //https://www.youtube.com/watch?v=wZ2UUOC17AY 

    //Gizmo
    float maxDistance = 150f;
    RaycastHit hit;

    //Bullet
    [Header ("Bullet Object")]
    public GameObject bullet;

    //Bullet life time
    private float bulletLifeTime = 2.0f;

    //Bullet Force
    [Header ("Bullet Force")]
    [SerializeField] float shootForce;
    [SerializeField] float upwardForce;

    //Gun stats
    [Header ("Gun Stats")]
    [SerializeField] float timeBetweenShooting;
    [SerializeField] float spread;
    [SerializeField] float reloadTime;
    [SerializeField] float timeBetweenShots;
    [SerializeField] int magazineSize;
    [SerializeField] int bulletPerTap;
    [SerializeField] bool allowButtonHold;

    // Bullet manager
        // Ints
        public int bulletsLeft;
        int bulletsShot;

        // Bools
        bool shooting;
        bool readyToShoot;
        bool reloading;

    // Reference
    public Camera fpsCam;
    public Transform attackPoint;

    // UI
    Image MagLeftUI;
    Text MagUI;
    float bulletUI = 0f;
    Toggle rapFirCheck;

    // Bug fixing
    public bool allowInvoke = true;  

    // Start is called before the first frame update
    void Awake()
    {
        // Make sure magazine is full.
        bulletsLeft = magazineSize;
        readyToShoot = true;
        MagLeftUI = GameObject.Find("BulletCount").GetComponent<Image>();
        MagUI = GameObject.Find("MagSize").GetComponent<Text>();
        rapFirCheck = GameObject.Find("Toggle").GetComponent<Toggle>();

        // Don't allow to rapidfire in beginnig.
        allowButtonHold = false;
        rapFirCheck.isOn = false;
    }

    // Update is called once per frame
    void Update()
    {
        // Manage bullets in magazine in UI.
        MagLeftUI.fillAmount = (bulletUI + bulletsLeft) / 100; 

        // Run method.
        rapidFire();

        // Bullets left UI.
        MagUI.text = $"{bulletsLeft}";

        // Run method.
        MyInput();
    }

    // Method that manages when and how to shoot.
    private void MyInput()
    {
        //check if allowed to hold down button and take corresponding input
        if (allowButtonHold)
        {
            shooting = Input.GetKey(KeyCode.Mouse0);
        }
        else
        {
            shooting = Input.GetKeyDown(KeyCode.Mouse0);
        }

        //Reloading
            // if (Input.GetKeyDown(KeyCode.R) && bulletsLeft < magazineSize && !reloading)
            // {
            //     Reload();
            // }

            // //Reload automatically when trying to shoot without ammo
            // if (readyToShoot && shooting && !reloading && bulletsLeft <=0)
            // {
            //     Reload();
            // }

        //shooting
        if (readyToShoot && shooting && /*!reloading &&*/ bulletsLeft > 0)
        {
            //Set bullets shot to 0
            bulletsShot = 0;

            Shoot();
        }
    }

    // Method that makes shooting work.
    private void Shoot()
    {
        readyToShoot = false;

        //Find the exact hit position using a raycast
        Ray ray = fpsCam.ViewportPointToRay(new Vector3 (0.5f, 0.5f, 0));
        RaycastHit hit;

        //check if ray hits something
        Vector3 targetPoint;
        if(Physics.Raycast(ray, out hit))
        {
            targetPoint = hit.point;
        }
        else
        {
            targetPoint = ray.GetPoint(75);
        }

        //Calculate direction from attackPoint to targetPoint
        Vector3 directionWithoutSpread = targetPoint - attackPoint.position;

        //Calculate spread
        float x = Random.Range(-spread, spread);
        float y = Random.Range(-spread, spread);

        //Calculate new direction with spread
        Vector3 directionWithSpread = directionWithoutSpread + new Vector3(x, y, 0);

        //Instantiate bullet
        GameObject currentBullet = Instantiate(bullet, attackPoint.position, Quaternion.identity);

        //Make bullet disapear again
        Destroy (currentBullet, bulletLifeTime);

        //Rotate bullet to shoot direction
        currentBullet.transform.forward = directionWithSpread.normalized;

        //Add force to bullet
        currentBullet.GetComponent<Rigidbody>().AddForce(directionWithoutSpread.normalized * shootForce, ForceMode.Impulse);
        currentBullet.GetComponent<Rigidbody>().AddForce(fpsCam.transform.up * upwardForce, ForceMode.Impulse);

        // Manage bullets
        bulletsLeft--;
        bulletsShot++;

        //Invoke resetShot function (if not already invoked), with your timeBetweenShooting
        if(allowInvoke)
        {
            Invoke("ResetShot", timeBetweenShooting);
            allowInvoke = false;
        }


        //if more than one bulletPerTap make sure to repeat shoot function
        if (bulletsShot < bulletPerTap &&  bulletsLeft > 0)
        {
            Invoke("Shoot", timeBetweenShots);
        }

    }
  
        // Method to allow shooting and invoking again.
        private void ResetShot()
        {
            readyToShoot = true;
            allowInvoke = true;
        }

    // Methods meant for reloading. (Not used)
        // private void Reload()
        // {
        //     reloading = true;
        //     Invoke("ReloadFinished", reloadTime);
        // }

        // private void ReloadFinished()
        // {
        //     MagUI.text = $"{magazineSize}";
        //     bulletsLeft = magazineSize;
        //     reloading = false;
        // }

    // Method to draw gizmo for gun.
    void OnDrawGizmos()
    {
        bool isHit = Physics.Raycast(transform.position, transform.forward, out hit, maxDistance
        );

        if(isHit)
        {
            Gizmos.color = Color.red;
            Gizmos.DrawRay(transform.position,transform.forward * hit.distance);
        }

        else
        {
            Gizmos.color = Color.green;
            Gizmos.DrawRay(transform.position,transform.forward * maxDistance);
        }
    }

    // Method to switch between single and rapid fire.
    void rapidFire()
    {
        if (Input.GetKeyDown(KeyCode.R) && allowButtonHold == true)
        {
            allowButtonHold = false;
            rapFirCheck.isOn = false;
        }

        else if (Input.GetKeyDown(KeyCode.R) && allowButtonHold == false)
        {
            allowButtonHold = true;
            rapFirCheck.isOn = true;
        }
    }
}
