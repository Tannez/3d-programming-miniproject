using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawn : MonoBehaviour
{
    // Script inspired by
    // https://answers.unity.com/questions/810806/spawn-random-enemy.html.

    // The prefabs to be spawned.
    [Header("Enemies To Spawn")]
    public GameObject[] objects;                

    // How long between each spawn.
    [Header("Enemy Spawn Time")]
    public float spawnTime = 1f;            
    private Vector3 spawnPosition;

    // Spawn area variables
    [Header("Enemy Spawn Range")]
    [SerializeField] float x1;
    [SerializeField] float x2;
    [SerializeField] float z1;
    [SerializeField] float z2;

    // Use this for initialization
    void Start()
    {
        // Call the Spawn function after a delay of the spawnTime and then continue to call after the same amount of time.
        InvokeRepeating("Spawn", spawnTime, spawnTime);
    }

    // Method to spawn objects in certain range.
    void Spawn()
    {
        spawnPosition.x = Random.Range(x1, x2);
        spawnPosition.y = 6190f;
        spawnPosition.z = Random.Range(z1, z2);

        Instantiate(objects[UnityEngine.Random.Range(0, objects.Length)], spawnPosition, Quaternion.identity);
    }
}