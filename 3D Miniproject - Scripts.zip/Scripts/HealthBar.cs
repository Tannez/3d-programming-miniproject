using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthBar : MonoBehaviour
{
    // Set health from beginnig.
    [Header("Set Player Health")]
    public float TotalHealth = 100;
    private float StartingHealth;

    // UI material.
    Image health;
    Text healthText;

    // Start is called before the first frame update
    void Start()
    {
        // Find UI objects for health.
        health = GameObject.Find("HealthBar").GetComponent<Image>();

        healthText = GameObject.Find("HealthText").GetComponent<Text>();

        // Value to make sure when health is set, it is devided correctly in health.fillAmount.
        StartingHealth = TotalHealth;
    }

    // Update is called once per frame
    void Update()
    {
        // Change Values in healthbar UI.
        health.fillAmount = TotalHealth / StartingHealth;

        healthText.text = $"{TotalHealth}";
    }

}
