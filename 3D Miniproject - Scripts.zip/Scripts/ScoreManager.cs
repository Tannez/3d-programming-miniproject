using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreManager : MonoBehaviour
{
    // Variable to be set in text of UI objects.
    public int totalScore;
    
    // UI Objects
    Text score;
    Text finalScoreText;

    // Start is called before the first frame update
    void Start()
    {
        // Find score and finalScore object components.
        score = GameObject.Find("Score").GetComponent<Text>();

        finalScoreText = GameObject.Find("FinalScoreNumber").GetComponent<Text>();

        // Set total score to 0 in beginning.
        totalScore = 0;
    }

    // Update is called once per frame
    void Update()
    {
        // Change UI text in object components.
        score.text = $"Score: {totalScore}";
        
        finalScoreText.text = $"{totalScore}";
    }
}
