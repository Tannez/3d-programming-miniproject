using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;

public class Enemy1 : MonoBehaviour
{
    // Enemy object.
    [Header("Enemy")]
    public GameObject Normal;

    // Enemy health.
    [Header("Enemy Health")]
    [SerializeField] int life;

    //Magazine Object and a transform to define where to spawn it.
    [Header ("Magazine Object")]
    public GameObject Mag;
    public Transform MagSpawn;

    // UI script Access.
    private HealthBar healthBar;
    private ScoreManager scoMan;

    // Damage for damage randomization.
    [Header("Damage Range")]
    [SerializeField] int lowDamage;
    [SerializeField] int highDamage;
    
    // nav mesh stuff
        // Target the enemy will follow.
    [Header("Enemy Target")]
    public Transform target;
    
        // Define nav mesh.
    NavMeshAgent nav;

    // Connect to Score UI.
    [Header("Points For Kill")]
    [SerializeField] int normalPoints;

    // Start is called before the first frame update
    void Start()
    {
        // Find NavMesh component
        nav = GetComponent<NavMeshAgent>();

        // Find healthbar object.
        healthBar = GameObject.Find("HealthBar").GetComponent<HealthBar>();

        // Find score manager object.
        scoMan = GameObject.Find("Score").GetComponent<ScoreManager>();
    }

    // Update is called once per frame
    void Update()
    {
        // Make object follow target (player).
        nav.SetDestination(target.position);

        //Run kill method.
        killEnemy();
    }

    // Method to kill enemy when they are out of health and adding points to score. 
    // Also instatiate a Mag object.
    void killEnemy()
    {
        if (life == 0)
        {
            scoMan.totalScore += normalPoints;
            GameObject currentMag = Instantiate(Mag, MagSpawn.position, Quaternion.identity);
            Normal.SetActive(false);
            Debug.Log("Enemy is Dead!");
        }  
    }

    // Trigger to make object able to get hit by bullet and damage player.
    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Bullet"))
        {
            life -= 1;
            Debug.Log("Enemy was hit!");
        }

        if (other.CompareTag("Player"))
        {
            healthBar.TotalHealth -= Random.Range(lowDamage, highDamage);
        }
    }
}

 
